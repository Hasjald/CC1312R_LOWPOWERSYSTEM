/***********************************************************************
 * Target Device: cc13x2_26x2
 ***********************************************************************/

#ifndef TASKS_NODERADIOTASKTASK_H_
#define TASKS_NODERADIOTASKTASK_H_

#include "stdint.h"
#ifdef USE_DMM
#include <ti/sysbios/knl/Task.h>
#endif /* USE_DMM */


enum NodeRadioOperationStatus {
    NodeRadioStatus_Success,
    NodeRadioStatus_Failed,
    NodeRadioStatus_FailedNotConnected,
};

/* Initializes the NodeRadioTask and creates all TI-RTOS objects */
#ifndef USE_DMM
void NodeRadioTask_init(void);
#else
Task_Handle* NodeRadioTask_init(void);
#endif

/* Sends a sensor value to the concentrator */
enum NodeRadioOperationStatus NodeRadioTask_sendAdcData(uint16_t data);

/* Get node address, return 0 if node address has not been set */
uint8_t nodeRadioTask_getNodeAddr(void);

#endif /* TASKS_NODERADIOTASKTASK_H_ */
