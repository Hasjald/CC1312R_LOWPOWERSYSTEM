/***********************************************************************
 * Target Device: cc13x2_26x2
 ***********************************************************************/

/* XDCtools Header files */
#include <NodeReed.h>
#include <NodeReedRadio.h>
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>

#include <ti/drivers/Power.h>
#include <ti/drivers/power/PowerCC26XX.h>

/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */


/*
 *  ======== main ========
 */
int main(void)
{
    /* Call driver init functions. */
    Board_initGeneral();


    /* Initialize sensor node tasks */
    NodeRadioTask_init();
    NodeTask_init();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
