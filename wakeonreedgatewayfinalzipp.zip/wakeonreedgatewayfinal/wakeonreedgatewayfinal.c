/******************************************************************************

 Target Device: cc13x2_26x2

 *****************************************************************************/
/* XDCtools Header files */
#include <reedgateway.h>
#include <reedgatewayradio.h>
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/drivers/Power.h>
#include <ti/drivers/power/PowerCC26XX.h>

/* TI-RTOS Header files */

#include <ti/drivers/PIN.h>



/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */ 

/*
 *  ======== main ========
 */
int main(void)
{
    /* Call driver init functions. */
    Board_initGeneral();

    /* Initialize the UART and SPI for the display driver. */




    /* Initialize concentrator tasks */
    ConcentratorRadioTask_init();
    ConcentratorTask_init();

    /* Start BIOS */
    BIOS_start();

    return (0);
}
