
/***** Includes *****/
/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Event.h>
#include <ti/sysbios/knl/Clock.h>

/* TI-RTOS Header files */
#include <ti/drivers/Power.h>
#include <ti/drivers/power/PowerCC26XX.h>
#include <ti/drivers/rf/RF.h>
#include <ti/drivers/PIN.h>
#include <ti/drivers/UART2.h>
/* Board Header files */
#include "ti_drivers_config.h"

/* Standard C Libraries */
#include <stdlib.h>

/* EasyLink API Header files */
#include "easylink/EasyLink.h"

/* Application Header files */
#include <ti/devices/DeviceFamily.h>
#include DeviceFamily_constructPath(driverlib/aon_batmon.h)
#include DeviceFamily_constructPath(driverlib/cpu.h)
#include <NodeRadioProtocol.h>
#include <NodeReed.h>
#include <NodeReedRadio.h>

/***** Defines *****/
#define NODERADIO_TASK_STACK_SIZE 1024
#define NODERADIO_TASK_PRIORITY   3

#define RADIO_EVENT_ALL                 0xFFFFFFFF
#define RADIO_EVENT_SEND_REED_DATA       (uint32_t)(1 << 0)
#define RADIO_EVENT_DATA_ACK_RECEIVED   (uint32_t)(1 << 1)
#define RADIO_EVENT_ACK_TIMEOUT         (uint32_t)(1 << 2)
#define RADIO_EVENT_SEND_FAIL           (uint32_t)(1 << 3)

#define NODERADIO_MAX_RETRIES       (2)
#define NODERADIO_ACK_TIMEOUT_MS    (160)


/***** Type declarations *****/
struct RadioOperation {
    EasyLink_TxPacket easyLinkTxPacket;
    uint8_t retriesDone;
    uint8_t maxNumberOfRetries;
    uint32_t ackTimeoutMs;
    enum NodeRadioOperationStatus result;
};

typedef struct {
    uint8_t           nCmdRejected;
    uint8_t           nRejectBeforEscalation;
    uint32_t          nTotalRejected;
    EasyLink_Priority cmdPriority;
}cmdPriorityEscalation_t;

/***** Variable declarations *****/
static Task_Params nodeRadioTaskParams;
Task_Struct nodeRadioTask;        /* not static so you can see in ROV */
static uint8_t nodeRadioTaskStack[NODERADIO_TASK_STACK_SIZE];
Semaphore_Struct radioAccessSem;  /* not static so you can see in ROV */
static Semaphore_Handle radioAccessSemHandle;
Event_Struct radioOperationEvent; /* not static so you can see in ROV */
static Event_Handle radioOperationEventHandle;
Semaphore_Struct radioResultSem;  /* not static so you can see in ROV */
static Semaphore_Handle radioResultSemHandle;
static struct RadioOperation currentRadioOperation;
static uint16_t ReedData;
static uint8_t nodeAddress = 8;
static struct DualModeSensorPacket dmSensorPacket;
static cmdPriorityEscalation_t rxCmdPriEsc = {
                                              .nCmdRejected  = 0U,
                                              .nRejectBeforEscalation = 2U,
                                              .cmdPriority   = EasyLink_Priority_Normal
                                             };
static cmdPriorityEscalation_t txCmdPriEsc = {
                                              .nCmdRejected  = 0U,
                                              .nRejectBeforEscalation = 2U,
                                              .cmdPriority   = EasyLink_Priority_Normal
                                             };

/* Track the number of commands successively rejected by the DMM */
uint8_t nTxCmdRejected = 0U, nRxCmdRejected;

/* Track the current WSN command priority */
EasyLink_Priority wsnTxCmdPriority, wsnRxCmdPriority;

/* previous Tick count used to calculate uptime */
static uint32_t prevTicks;

/***** Prototypes *****/
static void nodeRadioTaskFunction(UArg arg0, UArg arg1);
static void returnRadioOperationStatus(enum NodeRadioOperationStatus status);
static void sendDmPacket(struct DualModeSensorPacket sensorPacket, uint8_t maxNumberOfRetries, uint32_t ackTimeoutMs);
static void resendPacket(void);
static void rxDoneCallback(EasyLink_RxPacket * rxPacket, EasyLink_Status status);
static void updateCmdPriority(cmdPriorityEscalation_t* pCmdPriEsc, bool isCmdRejected);

/***** Function definitions *****/
#ifndef USE_DMM
void NodeRadioTask_init(void) {
#else
Task_Handle* NodeRadioTask_init(void) {
#endif /* !USE_DMM */

    /* Create semaphore used for exclusive radio access */
    Semaphore_Params semParam;
    Semaphore_Params_init(&semParam);
    Semaphore_construct(&radioAccessSem, 1, &semParam);
    radioAccessSemHandle = Semaphore_handle(&radioAccessSem);

    /* Create semaphore used for callers to wait for result */
    Semaphore_construct(&radioResultSem, 0, &semParam);
    radioResultSemHandle = Semaphore_handle(&radioResultSem);

    /* Create event used internally for state changes */
    Event_Params eventParam;
    Event_Params_init(&eventParam);
    Event_construct(&radioOperationEvent, &eventParam);
    radioOperationEventHandle = Event_handle(&radioOperationEvent);

    /* Create the radio protocol task */
    Task_Params_init(&nodeRadioTaskParams);
    nodeRadioTaskParams.stackSize = NODERADIO_TASK_STACK_SIZE;
    nodeRadioTaskParams.priority = NODERADIO_TASK_PRIORITY;
    nodeRadioTaskParams.stack = &nodeRadioTaskStack;
    Task_construct(&nodeRadioTask, nodeRadioTaskFunction, &nodeRadioTaskParams, NULL);

#ifdef USE_DMM
    nodeRadioTaskHndl = (Task_Handle) &nodeRadioTask;
    return &nodeRadioTaskHndl;
#endif /* USE_DMM */
}

uint8_t nodeRadioTask_getNodeAddr(void)
{
    return nodeAddress;
}


static void nodeRadioTaskFunction(UArg arg0, UArg arg1)
{

    /* Initialize the EasyLink parameters to their default values */
    EasyLink_Params easyLink_params;
    EasyLink_Params_init(&easyLink_params);

#ifdef DEFINED_RADIO_EASYLINK_MODULATION
    /* Change the modulation from the default found in ti_easylink_config.h */
    easyLink_params.ui32ModType = DEFINED_RADIO_EASYLINK_MODULATION;
#endif

    uint32_t noRadioAckTimeoutTimeMs = NODERADIO_ACK_TIMEOUT_MS;

#ifdef USE_DMM
    EasyLink_setCtrl(EasyLink_Ctrl_MultiClient_Mode, true);

    if (easyLink_params.ui32ModType == EasyLink_PHY_50KBPS2GFSK)
    {
        noRadioAckTimeoutTimeMs = 10;
    }
    else if (easyLink_params.ui32ModType == EasyLink_PHY_5KBPSSLLR)
    {
        noRadioAckTimeoutTimeMs = 100;
    }
#endif /* USE_DMM */


    /* Initialize EasyLink */
    if(EasyLink_init(&easyLink_params) != EasyLink_Status_Success){
        System_abort("EasyLink_init failed");
    }

    /* If you wich to use a frequency other than the default use
     * the below API
     * EasyLink_setFrequency(868000000);
     */

    /* Set the filter to the address */
    if (EasyLink_enableRxAddrFilter(&nodeAddress, 1, 1) != EasyLink_Status_Success)
    {
        System_abort("EasyLink_enableRxAddrFilter failed");
    }

    /* Setup sensor packet */
    dmSensorPacket.header.sourceAddress = nodeAddress;
    dmSensorPacket.header.packetType = RADIO_PACKET_TYPE_DM_SENSOR_PACKET;

    /* Initialise previous Tick count used to calculate uptime for the TLM beacon */
    prevTicks = Clock_getTicks();


    /* Enter main task loop */
    while (1)
    {
        /* Wait for an event */
        uint32_t events = Event_pend(radioOperationEventHandle, 0, RADIO_EVENT_ALL, BIOS_WAIT_FOREVER);

        /* If we should send ADC data */
        if (events & RADIO_EVENT_SEND_REED_DATA)
        {
            uint32_t currentTicks;

            currentTicks = Clock_getTicks();
            //check for wrap around
            if (currentTicks > prevTicks)
            {
                //calculate time since last reading in 0.1s units
                dmSensorPacket.time100MiliSec += ((currentTicks - prevTicks) * Clock_tickPeriod) / 100000;
            }
            else
            {
                //calculate time since last reading in 0.1s units
                dmSensorPacket.time100MiliSec += ((prevTicks - currentTicks) * Clock_tickPeriod) / 100000;
            }
            prevTicks = currentTicks;

            dmSensorPacket.batt = AONBatMonBatteryVoltageGet();
           /*
            * \return Returns the current battery monitor value of the battery voltage
            *             measurement in a <int.frac> format size <3.8> in units of volt.
            *             the uint returned is 32 bit while we stuff it into a 16 bit uint.
            */
            dmSensorPacket.Temp = AONBatMonTemperatureGetDegC();//returns temp in deg c int.
            dmSensorPacket.ReedValue = ReedData;


            sendDmPacket(dmSensorPacket, NODERADIO_MAX_RETRIES, noRadioAckTimeoutTimeMs);
        }

        /* If we get an ACK from the concentrator */
        if (events & RADIO_EVENT_DATA_ACK_RECEIVED)
        {
            returnRadioOperationStatus(NodeRadioStatus_Success);

        }

        /* If we get an ACK timeout */
        if (events & RADIO_EVENT_ACK_TIMEOUT)
        {

            /* If we haven't resent it the maximum number of times yet, then resend packet */
            if (currentRadioOperation.retriesDone < currentRadioOperation.maxNumberOfRetries)
            {
                resendPacket();
            }
            else
            {
                /* Else return send fail */
                Event_post(radioOperationEventHandle, RADIO_EVENT_SEND_FAIL);
            }
        }

        /* If send fail */
        if (events & RADIO_EVENT_SEND_FAIL)
        {
            returnRadioOperationStatus(NodeRadioStatus_Failed);

        }

    }
}

enum NodeRadioOperationStatus NodeRadioTask_sendAdcData(uint16_t data)
{
    enum NodeRadioOperationStatus status;

    /* Get radio access semaphore */
    Semaphore_pend(radioAccessSemHandle, BIOS_WAIT_FOREVER);

    /* Save data to send */
    ReedData = data;

    /* Raise RADIO_EVENT_SEND_REED_DATA event */
    Event_post(radioOperationEventHandle, RADIO_EVENT_SEND_REED_DATA);

    /* Wait for result */
    Semaphore_pend(radioResultSemHandle, BIOS_WAIT_FOREVER);

    /* Get result */
    status = currentRadioOperation.result;

    /* Return radio access semaphore */
    Semaphore_post(radioAccessSemHandle);

    return status;
}

static void returnRadioOperationStatus(enum NodeRadioOperationStatus result)
{
#if defined(USE_DMM) && !defined(USE_DMM_BLE_SP)
    /* update DMM policy */
    DMMPolicy_updateStackState(DMMPolicy_StackRole_WsnNode, DMMPOLICY_WSN_SLEEPING);

#endif /* USE_DMM && !USE_DMM_BLE_SP */

    /* Save result */
    currentRadioOperation.result = result;

    /* Post result semaphore */
    Semaphore_post(radioResultSemHandle);
}

static void sendDmPacket(struct DualModeSensorPacket sensorPacket, uint8_t maxNumberOfRetries, uint32_t ackTimeoutMs)
{
    EasyLink_Status wsnCmdStatus;

    /* Set destination address in EasyLink API */
    currentRadioOperation.easyLinkTxPacket.dstAddr[0] = RADIO_CONCENTRATOR_ADDRESS;

    /* Copy ADC packet to payload
     * Note that the EasyLink API will implcitily both add the length byte and the destination address byte. */
    currentRadioOperation.easyLinkTxPacket.payload[0] = dmSensorPacket.header.sourceAddress;
    currentRadioOperation.easyLinkTxPacket.payload[1] = dmSensorPacket.header.packetType;
    currentRadioOperation.easyLinkTxPacket.payload[2] = (dmSensorPacket.ReedValue & 0xFF00) >> 8;
    currentRadioOperation.easyLinkTxPacket.payload[3] = (dmSensorPacket.ReedValue & 0xFF);
    currentRadioOperation.easyLinkTxPacket.payload[4] = (dmSensorPacket.batt & 0xFF00) >> 8;
    currentRadioOperation.easyLinkTxPacket.payload[5] = (dmSensorPacket.batt & 0xFF);
    currentRadioOperation.easyLinkTxPacket.payload[6] = (dmSensorPacket.Temp & 0xFF00) >> 8;
    currentRadioOperation.easyLinkTxPacket.payload[7] = (dmSensorPacket.Temp & 0xFF);
    currentRadioOperation.easyLinkTxPacket.payload[8] = (dmSensorPacket.time100MiliSec & 0xFF000000) >> 24;
    currentRadioOperation.easyLinkTxPacket.payload[9] = (dmSensorPacket.time100MiliSec & 0x00FF0000) >> 16;
    currentRadioOperation.easyLinkTxPacket.payload[10] = (dmSensorPacket.time100MiliSec & 0xFF00) >> 8;
    currentRadioOperation.easyLinkTxPacket.payload[11] = (dmSensorPacket.time100MiliSec & 0xFF);

    currentRadioOperation.easyLinkTxPacket.len = sizeof(struct DualModeSensorPacket);

    /* Setup retries */
    currentRadioOperation.maxNumberOfRetries = maxNumberOfRetries;
    currentRadioOperation.ackTimeoutMs = ackTimeoutMs;
    currentRadioOperation.retriesDone = 0;
    EasyLink_setCtrl(EasyLink_Ctrl_AsyncRx_TimeOut, EasyLink_ms_To_RadioTime(ackTimeoutMs));
#ifdef USE_DMM
    /* update DMM policy */
    DMMPolicy_updateStackState(DMMPolicy_StackRole_WsnNode, DMMPOLICY_WSN_TX);

#endif /* USE_DMM */

    /* Set the priority for the current transmission */
    EasyLink_setCtrl(EasyLink_Ctrl_Cmd_Priority, (uint32_t)txCmdPriEsc.cmdPriority);
    /* Send packet  */
    wsnCmdStatus = EasyLink_transmit(&currentRadioOperation.easyLinkTxPacket);
    if (wsnCmdStatus != EasyLink_Status_Success)
    {
        if(wsnCmdStatus == EasyLink_Status_Cmd_Rejected)
        {
            updateCmdPriority(&txCmdPriEsc, true);
        }
        Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);

    }
    else
    {
        /* Transmit was successful, return priority to normal */
        updateCmdPriority(&txCmdPriEsc, false);
    }

#ifdef USE_DMM
    /* update DMM policy */
    DMMPolicy_updateStackState(DMMPolicy_StackRole_WsnNode, DMMPOLICY_WSN_ACK);
#endif /* USE_DMM */
    /* Set the priority for the current reception */
    EasyLink_setCtrl(EasyLink_Ctrl_Cmd_Priority, (uint32_t)rxCmdPriEsc.cmdPriority);
    /* Enter RX */
    wsnCmdStatus = EasyLink_receiveAsync(rxDoneCallback, 0);
#if defined(DEBUG)
    /* Simulate command rejection  */
    EasyLink_abort();
#endif // DEBUG
    if (wsnCmdStatus != EasyLink_Status_Success)
    {
        if(wsnCmdStatus == EasyLink_Status_Cmd_Rejected)
        {
            updateCmdPriority(&rxCmdPriEsc, true);
        }
        Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);

    }
    else
    {
        /* Receive was successful, return priority to normal */
        updateCmdPriority(&rxCmdPriEsc, false);
    }
}

static void resendPacket(void)
{
    EasyLink_Status wsnCmdStatus;

#ifdef USE_DMM
    /* update DMM policy */
    DMMPolicy_updateStackState(DMMPolicy_StackRole_WsnNode, DMMPOLICY_WSN_TX);

#endif /* USE_DMM */
    /* Set the priority for the current transmission */
    EasyLink_setCtrl(EasyLink_Ctrl_Cmd_Priority, (uint32_t)txCmdPriEsc.cmdPriority);
    /* Send packet  */
    wsnCmdStatus = EasyLink_transmit(&currentRadioOperation.easyLinkTxPacket);
    if (wsnCmdStatus != EasyLink_Status_Success)
    {
        if(wsnCmdStatus == EasyLink_Status_Cmd_Rejected)
        {
            updateCmdPriority(&txCmdPriEsc, true);
        }
        Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);

    }
    else
    {
        /* Transmit was successful, return priority to normal */
        updateCmdPriority(&txCmdPriEsc, false);
    }

#ifdef USE_DMM
    /* Update DMM policy */
    DMMPolicy_updateStackState(DMMPolicy_StackRole_WsnNode, DMMPOLICY_WSN_ACK);
#endif /* USE_DMM */
    /* Set the priority for the current reception */
    EasyLink_setCtrl(EasyLink_Ctrl_Cmd_Priority, (uint32_t)rxCmdPriEsc.cmdPriority);
    /* Enter RX and wait for ACK with timeout */
    wsnCmdStatus = EasyLink_receiveAsync(rxDoneCallback, 0);
    if (wsnCmdStatus != EasyLink_Status_Success)
    {
        if(wsnCmdStatus == EasyLink_Status_Cmd_Rejected)
        {
            updateCmdPriority(&rxCmdPriEsc, true);
        }
        Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);

    }
    else
    {
        /* Receive was successful, return priority to normal */
        updateCmdPriority(&rxCmdPriEsc, false);
    }

    /* Increase retries by one */
    currentRadioOperation.retriesDone++;
}


static void rxDoneCallback(EasyLink_RxPacket * rxPacket, EasyLink_Status status)
{
    struct PacketHeader* packetHeader;

    /* If this callback is called because of a packet received */
    if (status == EasyLink_Status_Success)
    {
        /* Check the payload header */
        packetHeader = (struct PacketHeader*)rxPacket->payload;

        /* Check if this is an ACK packet */
        if (packetHeader->packetType == RADIO_PACKET_TYPE_ACK_PACKET)
        {
            /* Signal ACK packet received */
            Event_post(radioOperationEventHandle, RADIO_EVENT_DATA_ACK_RECEIVED);
        }
        else
        {
            /* Packet Error, treat as a Timeout and Post a RADIO_EVENT_ACK_TIMEOUT
               event */
            Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);

        }
    }
    /* did the Rx timeout */
    else if(status == EasyLink_Status_Rx_Timeout)
    {
        /* Post a RADIO_EVENT_ACK_TIMEOUT event */
        Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);

    }
    else
    {
        /* The Ack reception may have been corrupted causing an error.
         * Treat this as a timeout
         */
        Event_post(radioOperationEventHandle, RADIO_EVENT_ACK_TIMEOUT);
    }
}

static void updateCmdPriority(cmdPriorityEscalation_t* pCmdPriEsc, bool isCmdRejected)
{
    if(isCmdRejected == true)
    {
        /* update total cmd-rejected count */
        pCmdPriEsc->nTotalRejected++;
        /* command was rejected */
        if(++(pCmdPriEsc->nCmdRejected) == pCmdPriEsc->nRejectBeforEscalation)
        {
            pCmdPriEsc->nCmdRejected = 0U;
            if(pCmdPriEsc->cmdPriority != EasyLink_Priority_Urgent)
            {
                /* Bump the priority, unless already at urgent, when N_REJECT_TO_ESCALATE_PRIORITY
                 * commands are successively rejected
                 */
                (pCmdPriEsc->cmdPriority)++;
            }
        }
    }
    else // isCmdRejected == false
    {
        /* Command was successful, reset count and return priority to normal */
        pCmdPriEsc->nCmdRejected = 0U;
        pCmdPriEsc->cmdPriority  = EasyLink_Priority_Normal;
    }
}
