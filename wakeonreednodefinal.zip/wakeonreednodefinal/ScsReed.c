
/***** Includes *****/
#include <ScsReed.h>
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* SCE Header files */
#include "scs/scif.h"
#include "scs/scif_framework.h"
#include "scs/scif_osal_tirtos.h"


/***** Variable declarations *****/
static Scs_reedswitchcallback reedswitchCallback;


/***** Prototypes *****/
static void ctrlReadyCallback(void);
static void taskAlertCallback(void);


/***** Function definitions *****/
void Scsreed_init(uint32_t samplingTime) {
    // Initialize the Sensor Controller
    scifOsalInit();
    scifOsalRegisterCtrlReadyCallback(ctrlReadyCallback);
    scifOsalRegisterTaskAlertCallback(taskAlertCallback);
    scifInit(&scifDriverSetup);
    scifStartRtcTicksNow(samplingTime);


}

void ScsReed_start(void) {
    // Start task
    scifStartTasksNbl((1 <<SCIF_REED_SWITCH_TASK_ID));
}

void ScsReed_registerCallback(Scs_reedswitchcallback callback) {
    reedswitchCallback = callback;
}

static void ctrlReadyCallback(void) {
    /* Do nothing */
}

static void taskAlertCallback(void) {

    /* Clear the ALERT interrupt source */
    scifClearAlertIntSource();

    /* Only handle the periodic event alert */
    if (scifGetAlertEvents() & (1 << SCIF_REED_SWITCH_TASK_ID))
    {

        /* Get the scs "output" structure */
        SCIF_REED_SWITCH_OUTPUT_T* pOutput = scifGetTaskStruct(SCIF_REED_SWITCH_TASK_ID, SCIF_STRUCT_OUTPUT);

        /* Send new value to application via callback */
        if (reedswitchCallback)
        {
            reedswitchCallback(pOutput->isReedSwitchOpen);
        }
    }

    /* Acknowledge the alert event */
    scifAckAlertEvents();
}
