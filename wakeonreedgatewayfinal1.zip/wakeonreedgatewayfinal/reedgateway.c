/******************************************************************************

 Target Device: cc13x2_26x2
 
 
 *****************************************************************************/

/***** Includes *****/
/* XDCtools Header files */ 
#include <xdc/std.h>
#include <xdc/runtime/System.h>
#include <stdio.h>
#include <stdlib.h>

/* BIOS Header files */ 
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Event.h>

/* TI-RTOS Header files */
#include <ti/drivers/PIN.h>
#include <ti/devices/DeviceFamily.h>
#include DeviceFamily_constructPath(driverlib/cpu.h)

/* Board Header files */
#include "ti_drivers_config.h"
#include <ti/drivers/UART2.h>
/* application header files*/
#include <reedgateway.h>
#include <reedgatewayradio.h>
#include <Reedradioprotocol.h>

/***** Defines *****/

#define CONCENTRATOR_TASK_STACK_SIZE 1024
#define CONCENTRATOR_TASK_PRIORITY   3

#define CONCENTRATOR_EVENT_ALL                         0xFFFFFFFF
#define CONCENTRATOR_EVENT_NEW_SENSOR_VALUE    (uint32_t)(1 << 0)

#define CONCENTRATOR_MAX_NODES 2    //increase this and isknownnodes struct will increase.

/***** Type declarations *****/
struct AdcSensorNode {
    uint8_t address;
    uint16_t latestReedValue;
    uint16_t latestTemp;
    uint16_t latestbatt;
    int8_t latestRssi;
};

/***** Variable declarations *****/
static Task_Params concentratorTaskParams;
Task_Struct concentratorTask;    /* not static so you can see in ROV */
static uint8_t concentratorTaskStack[CONCENTRATOR_TASK_STACK_SIZE];
Event_Struct concentratorEvent;  /* not static so you can see in ROV */
static Event_Handle concentratorEventHandle;
static struct AdcSensorNode latestActiveAdcSensorNode;
struct AdcSensorNode knownSensorNodes[CONCENTRATOR_MAX_NODES];
static struct AdcSensorNode* lastAddedSensorNode = knownSensorNodes;

/***** Prototypes *****/
static void concentratorTaskFunction(UArg arg0, UArg arg1);
static void packetReceivedCallback(union ConcentratorPacket* packet, int8_t rssi);
static void updateuart2(void);
static void addNewNode(struct AdcSensorNode* node);
static void updateNode(struct AdcSensorNode* node);
static uint8_t isKnownNodeAddress(uint8_t address);


/***** Function definitions *****/
void ConcentratorTask_init(void) {

    /* Create event used internally for state changes */
    Event_Params eventParam;
    Event_Params_init(&eventParam);
    Event_construct(&concentratorEvent, &eventParam);
    concentratorEventHandle = Event_handle(&concentratorEvent);

    /* Create the concentrator radio protocol task */
    Task_Params_init(&concentratorTaskParams);
    concentratorTaskParams.stackSize = CONCENTRATOR_TASK_STACK_SIZE;
    concentratorTaskParams.priority = CONCENTRATOR_TASK_PRIORITY;
    concentratorTaskParams.stack = &concentratorTaskStack;
    Task_construct(&concentratorTask, concentratorTaskFunction, &concentratorTaskParams, NULL);


}

static void concentratorTaskFunction(UArg arg0, UArg arg1)
{

    /* Register a packet received callback with the radio task */
    ConcentratorRadioTask_registerPacketReceivedCallback(packetReceivedCallback);

    /* Enter main task loop */
    while(1) {
        /* Wait for event */
        uint32_t events = Event_pend(concentratorEventHandle, 0, CONCENTRATOR_EVENT_ALL, BIOS_WAIT_FOREVER);

        /* If we got a new sensor value *//* the value */
            if(isKnownNodeAddress(latestActiveAdcSensorNode.address)) {
                updateNode(&latestActiveAdcSensorNode);
            }
            else {
                /* Else add it */

                addNewNode(&latestActiveAdcSensorNode);
            }

            /* Update the values to the esp32 */

            updateuart2();

        }
}


static void packetReceivedCallback(union ConcentratorPacket* packet, int8_t rssi)
{
    /* If we recived a sensor packet, for backward compatibility */
    if (packet->header.packetType == RADIO_PACKET_TYPE_REED_SENSOR_PACKET)
    {
        /* Save the values */
        latestActiveAdcSensorNode.address = packet->header.sourceAddress;
        latestActiveAdcSensorNode.latestReedValue = packet->reedSensorPacket.ReedValue;
        latestActiveAdcSensorNode.latestRssi = rssi;

        Event_post(concentratorEventHandle, CONCENTRATOR_EVENT_NEW_SENSOR_VALUE);
    }
    /* If we recived an DualMode sensor packet*/
    else if(packet->header.packetType == RADIO_PACKET_TYPE_DM_SENSOR_PACKET)
    {

        /* Save the values */
        latestActiveAdcSensorNode.address = packet->header.sourceAddress;
        latestActiveAdcSensorNode.latestReedValue = packet->dmSensorPacket.ReedValue;
        latestActiveAdcSensorNode.latestTemp = packet->dmSensorPacket.Temp;
        latestActiveAdcSensorNode.latestbatt = packet->dmSensorPacket.batt;
        latestActiveAdcSensorNode.latestRssi = rssi;

        Event_post(concentratorEventHandle, CONCENTRATOR_EVENT_NEW_SENSOR_VALUE);

    }
}

static uint8_t isKnownNodeAddress(uint8_t address) {
    uint8_t found = 0;
    uint8_t i;
    for (i = 0; i < CONCENTRATOR_MAX_NODES; i++)
    {
        if (knownSensorNodes[i].address == address)
        {
            found = 1;
            break;
        }
    }
    return found;
}


static void updateNode(struct AdcSensorNode* node) {
    uint8_t i;
    for (i = 0; i < CONCENTRATOR_MAX_NODES; i++) {
        if (knownSensorNodes[i].address == node->address)
        {
            knownSensorNodes[i].latestReedValue = node->latestReedValue;
            knownSensorNodes[i].latestbatt = node->latestbatt;
            knownSensorNodes[i].latestTemp = node->latestTemp;
            knownSensorNodes[i].latestRssi = node->latestRssi;
            break;
        }
    }
}

static void addNewNode(struct AdcSensorNode* node) {
    *lastAddedSensorNode = *node;

    /* Increment and wrap */
    lastAddedSensorNode++;
    if (lastAddedSensorNode > &knownSensorNodes[CONCENTRATOR_MAX_NODES-1])
    {
        lastAddedSensorNode = knownSensorNodes;
    }
}

static void updateuart2(void) {
    struct AdcSensorNode* nodePointer = knownSensorNodes;
/*UART INSTANCE*/

    /* Initialize UART and write */
        size_t  bytesWritten;
        char input[32];
        uint16_t holder[6];

//using uart in blocking mode
        UART2_Handle uart;
        UART2_Params uartParams;
        UART2_Params_init(&uartParams);
        uartParams.baudRate = 115200;
        uart = UART2_open(CONFIG_UART2_0, &uartParams);


/* added #define UDMA_CHAN_UART1_RX      5   // UART1 RX Data
         #define UDMA_CHAN_UART1_TX      6   // UART1 RX Data to udma.h
         temporary workaround for multiple uarts.
         DO NOT EDIT your udma.h if only using 1 uart or later ccs version than 9.1
         dio 1 is send see .syscfg for more
*/
    if (uart == NULL) {
            // UART_open() failed
            while (1);

        }

        /*hold the adress and reed value for conversion*/

        holder[1]=nodePointer->address;
        holder[2]=nodePointer->latestReedValue;
        holder[3]=nodePointer->latestbatt;
        holder[4]=nodePointer->latestTemp;
        //holder[5]= abs(nodePointer->latestRssi);//rssi can be nagative so we just want to know the absolute value


        sprintf(input, "ntnuGateway%.2X:%i:%i:%i:", holder[1],holder[4],holder[2],holder[3]); //change to char
        UART2_write(uart, &input, 32, &bytesWritten);//write more bytes than needed
        UART2_close(uart);

}
