/***********************************************************************
 * Target Device: cc13x2_26x2
 ***********************************************************************/
#ifndef SCSREED_H_
#define SCSREED_H_

#include "stdint.h"
#include "scs/scif.h"


typedef void(*Scs_reedswitchcallback)(uint16_t reedval, uint16_t adc1val, uint16_t adc2val);

/* Intializes the SCS sampling task.
 *
 * Note that this does not start the task.
 */
void Scsreed_init(uint32_t samplingTime);

/* Sets the SCS sampling
 *
 * Note that this can be called after the task has been started.
 */

void ScsReed_registerCallback(Scs_reedswitchcallback callback);

/* Starts the SCS task.
 *
 * The task has to be initialized using Scsreed_init before being started.
 * */
void ScsReed_start(void);



#endif /* SCSREED_H_ */
