/***********************************************************************
 * Target Device: cc13x2_26x2
 ***********************************************************************/

/***** Includes *****/
/* XDCtools Header files */
#include <NodeReed.h>
#include <NodeReedRadio.h>
#include <ScsReed.h>
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Event.h>
#include <ti/sysbios/knl/Clock.h>

/* TI-RTOS Header files */
#include <ti/drivers/PIN.h>


#include <ti/devices/DeviceFamily.h>
#include DeviceFamily_constructPath(driverlib/cpu.h)



/* Board Header files */
#include "ti_drivers_config.h"

/* Application Header files */

/***** Defines *****/
#define NODE_TASK_STACK_SIZE 1024
#define NODE_TASK_PRIORITY   3

#define NODE_EVENT_ALL                  0xFFFFFFFF
#define NODE_EVENT_NEW_REED_VALUE    (uint32_t)(1 << 0)

#define REED_SWITCH_SAMPLE_HZ          64



/***** Variable declarations *****/
static Task_Params nodeTaskParams;
Task_Struct nodeTask;    /* Not static so you can see in ROV */
static uint8_t nodeTaskStack[NODE_TASK_STACK_SIZE];
Event_Struct nodeEvent;  /* Not static so you can see in ROV */
static Event_Handle nodeEventHandle;


static uint16_t latestreedswitchValue;
static uint16_t latestAdc1Value;
static uint16_t latestadc2value;


/***** Prototypes *****/
static void nodeTaskFunction(UArg arg0, UArg arg1);
static void adcCallback(uint16_t reedswitchsample,uint16_t adc1sample,uint16_t adc2sample);


/***** Function definitions *****/
void NodeTask_init(void)
{
    /* Create event used internally for state changes */
    Event_Params eventParam;
    Event_Params_init(&eventParam);
    Event_construct(&nodeEvent, &eventParam);
    nodeEventHandle = Event_handle(&nodeEvent);

    /* Create the node task */
    Task_Params_init(&nodeTaskParams);
    nodeTaskParams.stackSize = NODE_TASK_STACK_SIZE;
    nodeTaskParams.priority = NODE_TASK_PRIORITY;
    nodeTaskParams.stack = &nodeTaskStack;
    Task_construct(&nodeTask, nodeTaskFunction, &nodeTaskParams, NULL);
}

static void nodeTaskFunction(UArg arg0, UArg arg1)
{




    /* Start the SCS task with 2 min sample period and reacting to change in Reed switch sensor. */
    Scsreed_init(0x00020000);
    ScsReed_registerCallback(adcCallback);
    ScsReed_start();


    while (1)
    {
        /* Wait for event */
        uint32_t events = Event_pend(nodeEventHandle, 0, NODE_EVENT_ALL, BIOS_WAIT_FOREVER);

        /* If new value, send this data */
        if (events & NODE_EVENT_NEW_REED_VALUE) {


            /* Send value to concentrator */
            NodeRadioTask_sendAdcData(latestreedswitchValue, latestAdc1Value, latestadc2value);

        }
    }
}

static void adcCallback(uint16_t reedswitchsample,uint16_t adc1sample,uint16_t adc2sample)
{
    /* Save latest value */
    latestreedswitchValue = reedswitchsample;
    latestAdc1Value = adc1sample;
    latestadc2value = adc2sample;


    /* Post event */
    Event_post(nodeEventHandle, NODE_EVENT_NEW_REED_VALUE);
}



