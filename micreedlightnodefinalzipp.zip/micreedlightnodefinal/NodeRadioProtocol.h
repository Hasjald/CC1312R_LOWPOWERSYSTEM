/***********************************************************************
 * Target Device: cc13x2_26x2
 ***********************************************************************/

#ifndef NODERADIOPROTOCOL_H_
#define NODERADIOPROTOCOL_H_

#include "stdint.h"
#include "easylink/EasyLink.h"

#define RADIO_CONCENTRATOR_ADDRESS     0x00

/*
 * Uncomment to change the modulation away from the default found in the
 * EASYLINK_PARAM_CONFIG macro in ti_easylink_config.h
 *
 * Valid values can be found in the EasyLink_PhyType enum in EasyLink.h
 */
//#define DEFINED_RADIO_EASYLINK_MODULATION     EasyLink_Phy_Custom

#define RADIO_PACKET_TYPE_ACK_PACKET             0
#define RADIO_PACKET_TYPE_REED_SENSOR_PACKET     1
#define RADIO_PACKET_TYPE_DM_SENSOR_PACKET       2

struct PacketHeader {
    uint8_t sourceAddress;
    uint8_t packetType;
};

struct ReedSensorPacket {
    struct PacketHeader header;
    uint16_t ReedValue;
};

struct DualModeSensorPacket {
    struct PacketHeader header;
    uint16_t ReedValue;
    uint16_t adcValue1;
    uint16_t adcValue2;
    uint16_t batt;
    uint16_t temp;
    uint32_t time100MiliSec;
};

struct AckPacket {
    struct PacketHeader header;
};

#endif /* NODERADIOPROTOCOL_H_ */
